#include "../src/xgettext.c"
