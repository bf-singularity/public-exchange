See ppm.md manual and INSTALL.md
